the weighted matrix : the weight of miRNA functional similarity
miRNA functional similarity: