disease semantic similarity 1��computed from the Disease semantic similarity model 1
the weighted matrix : the weight of disease semantic similarity