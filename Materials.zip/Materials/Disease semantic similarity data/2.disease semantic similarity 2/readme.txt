disease semantic similarity 2��computed from the Disease semantic similarity model 2
the weighted matrix : the weight of disease semantic similarity